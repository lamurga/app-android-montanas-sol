package com.diana.tbfinal;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AdaptadorPersonalizado extends RecyclerView.Adapter<AdaptadorPersonalizado.MyViewHolder> {
    private Context context;
    private List<Producto> listaProductos = new ArrayList<>();

    public AdaptadorPersonalizado(Context context,List<Producto> listaProductos){
        this.context = context;
        this.listaProductos = listaProductos;
    }
    @NonNull
    @Override
    public AdaptadorPersonalizado.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.fila,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorPersonalizado.MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.filaNombre.setText(listaProductos.get(position).getNombre());
        holder.filaCategoria.setText(listaProductos.get(position).getCategoria());
        holder.filaCantidad.setText(listaProductos.get(position).getCantidad()+"");
        holder.filaPrecio.setText(listaProductos.get(position).getPrecio()+"");
        holder.filaCorreo.setText(listaProductos.get(position).getCorreo()+"");
        holder.filaCampania.setText(listaProductos.get(position).getCampania());
        holder.fila.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Intent intent = new Intent(context,RegistrarActivity.class);
                intent.putExtra("pid",listaProductos.get(position).getId()+"");
                intent.putExtra("pnombre",listaProductos.get(position).getNombre()+"");
                intent.putExtra("pcategoria",listaProductos.get(position).getCategoria()+"");
                intent.putExtra("pcantidad",listaProductos.get(position).getCantidad()+"");
                intent.putExtra("pprecio",listaProductos.get(position).getPrecio()+"");
                intent.putExtra("pcorreo",listaProductos.get(position).getCorreo()+"");
                intent.putExtra("pcampania",listaProductos.get(position).getCampania()+"");
                context.startActivity(intent);
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaProductos.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView filaNombre,filaCategoria,filaCantidad,filaPrecio,filaCorreo,filaCampania;
        LinearLayout fila;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            filaNombre = itemView.findViewById(R.id.filaNombre);
            filaCategoria = itemView.findViewById(R.id.filaCategoria);
            filaCantidad = itemView.findViewById(R.id.filaCantidad);
            filaPrecio = itemView.findViewById(R.id.filaPrecio);
            filaCorreo = itemView.findViewById(R.id.filaCorreo);
            filaCampania = itemView.findViewById(R.id.filaCampania);
            fila = itemView.findViewById(R.id.fila);
        }
    }
}
