package com.diana.tbfinal;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.UUID;

public class RegistrarActivity extends AppCompatActivity {

    EditText txtNombre, txtCategoria, txtCantidad, txtPrecio, txtCorreo, txtCampania;
    Button btnRegistrar;

    FirebaseDatabase database;
    DatabaseReference reference;

    Producto producto;
    boolean registra = true;
    HashMap map = new HashMap();
    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar);
        asignarReferencias();
        obtenerValores();
        inicializarFirebase();
    }

    private void obtenerValores(){
        if(getIntent().hasExtra("pid")){
            registra = false;
            id = getIntent().getStringExtra("pid");
            txtNombre.setText(getIntent().getStringExtra("ppnombre"));
            txtCategoria.setText(getIntent().getStringExtra("pcategoria"));
            txtCantidad.setText(getIntent().getStringExtra("pcantidad"));
            txtPrecio.setText(getIntent().getStringExtra("pprecio"));
            txtCorreo.setText(getIntent().getStringExtra("pcorreo"));
            txtCampania.setText(getIntent().getStringExtra("pcampania"));
        }
    }

    private void asignarReferencias() {
        txtNombre = findViewById(R.id.txtNombre);
        txtCategoria = findViewById(R.id.txtCategoria);
        txtCantidad = findViewById(R.id.txtCantidad);
        txtPrecio = findViewById(R.id.txtPrecio);
        txtCorreo = findViewById(R.id.txtCorreo);
        txtCampania = findViewById(R.id.txtCampania);
        btnRegistrar = findViewById(R.id.btnRegistrar);
        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (capturarDatos()){
                    String mensaje = "";
                    if(registra){
                        reference.child("Producto").child(producto.getId()).setValue(producto);
                        mensaje = "Se inserto el producto";
                    }else {
                        reference.child("Producto").child(id).updateChildren(map);
                        mensaje = "Se actualizo el producto";
                    }

                    AlertDialog.Builder ventana = new AlertDialog.Builder(RegistrarActivity.this);
                    ventana.setTitle("Mensaje informativo");
                    ventana.setMessage(mensaje);
                    ventana.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    });
                    ventana.create().show();
                }
            }
        });
    }
    private void inicializarFirebase(){
        FirebaseApp.initializeApp(this);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference();
    }
    private boolean capturarDatos(){
        String nombre = txtNombre.getText().toString();
        String categoria = txtCategoria.getText().toString();
        String cantidad = txtCantidad.getText().toString();
        String precio = txtPrecio.getText().toString();
        String correo = txtCorreo.getText().toString();
        String campania = txtCampania.getText().toString();
          boolean valida = true;

        if(nombre.equals("")){
            txtNombre.setError("Nombre es obligatorio");
            valida = false;

        }
        if(categoria.equals("")){
            txtCategoria.setError("Categoria es obligatorio");
            valida = false;
        }
        if(cantidad.equals("")){
            txtCantidad.setError("Cantidad es obligatorio");
            valida = false;
        }
        if(precio.equals("")){
            txtPrecio.setError("Precio es obligatorio");
            valida = false;
        }
        if(correo.equals("")){
            txtCorreo.setError("Correo es obligatorio");
            valida = false;
        }
        if(campania.equals("")){
            txtCampania.setError("Campania es obligatorio");
            valida = false;
        }
        if(valida){
            if(registra){
                producto = new Producto();
                producto.setId(UUID.randomUUID().toString());
                producto.setNombre(nombre);
                producto.setCategoria(categoria);
                producto.setCantidad(cantidad);
                producto.setPrecio(precio);
                producto.setCorreo(correo);
                producto.setCampania(campania);
            }else {
                map.put("nombre", nombre);
                map.put("categoria",categoria);
                map.put("cantidad",cantidad);
                map.put("precio",precio);
                map.put("correo",correo);
                map.put("campania",campania);
            }

        }
        return valida;
    }

}