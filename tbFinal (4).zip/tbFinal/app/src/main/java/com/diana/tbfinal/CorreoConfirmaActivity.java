package com.diana.tbfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CorreoConfirmaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_correo_confirma);
    }
}