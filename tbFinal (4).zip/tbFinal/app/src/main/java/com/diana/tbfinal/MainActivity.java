package com.diana.tbfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    FloatingActionButton btnNuevo;
    RecyclerView rvProductos;

    FirebaseDatabase database;
    DatabaseReference reference;
    private List<Producto> listaProductos = new ArrayList<>();

    AdaptadorPersonalizado adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        asignarReferencias();
        inicializarFirebase();
        mostrarDatos();
    }
    private void inicializarFirebase(){
        FirebaseApp.initializeApp(this);
        database = FirebaseDatabase.getInstance();
        reference = database.getReference();
    }
    private void mostrarDatos(){
        reference.child("Producto").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
              listaProductos.clear();
              for(DataSnapshot item: snapshot.getChildren()){
                  Producto p = item.getValue(Producto.class);
                  listaProductos.add(p);
              }
             // productoArrayAdapter = new ArrayAdapter<Producto>(MainActivity.this, android.R.layout.simple_list_item_1,listaProductos);
              //lstProductos.setAdapter(productoArrayAdapter);
                adaptador = new AdaptadorPersonalizado(MainActivity.this,listaProductos);
                rvProductos.setAdapter(adaptador);
                rvProductos.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int pos = viewHolder.getAdapterPosition();
                String id = listaProductos.get(pos).getId();
                listaProductos.remove(pos);
                listaProductos.remove(viewHolder.getAdapterPosition());
                adaptador.notifyDataSetChanged();
                reference.child("Producto").child(id).removeValue();
            }
        }).attachToRecyclerView(rvProductos);
    }

    private  void  asignarReferencias(){
        btnNuevo = findViewById(R.id.btnNuevo);
        rvProductos = findViewById(R.id.rvProductos);
        btnNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,RegistrarActivity.class);
                startActivity(intent);
            }
        });
    }
}